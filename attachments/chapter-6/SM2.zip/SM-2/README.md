Supplementary Material: 2
Study:  Top-down design of microbial catalysis platforms for large libraries of product synthesis modules
Authors: Sergio Garcia and Cong Trinh.
Corresponding author: ctrinh@utk.edu
---

- This S.M. contains all code associated with ModCell-HPC and the generated results.

- Some files in the results and analysis are linked to git-lfs due to their large size, to obtain the entire repository retrieve it online at:
https://github.com/TrinhLab/modcell-hpc-study
To obtain all files clone with `git lfs clone`.

To obtain the current version of ModCell-HPC visit:
https://github.com/TrinhLab/modcell-hpc

