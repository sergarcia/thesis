# General description
 Like case 2 but with an increased population size.


