The notebooks presented here generate and analyze the results for the ecoli core model and example network problems,
 see $modcell2/problems for more examples.
