example network model

Example network model
---------------------
.. raw:: html
   :file: ../../examples/html/example_network.html
