.. _general

general
-------
.. automodule:: src.support.general
        :members:


