This site incluse examples, usage tips, and comprehensive module documentation for the ModCell2 strain design tool. 

The source code can be found at: https://github.com/trinhlab/modcell2

.. include:: ../../CITATION.rst
