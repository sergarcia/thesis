.. _ecoli_core

E. coli core model with fixed module reactions
----------------------------------------------
.. raw:: html
   :file: ../../examples/html/ecoli_core_trinh_fixed_module_reactions.html
   
