If you use any part of this software, please cite:
::
        Sergio Garcia, Cong T. Trinh,
        Multiobjective strain design: A framework for modular cell engineering,
        Metabolic Engineering,
        Volume 51,
        2019,
        Pages 110-120,
        ISSN 1096-7176,
        https://doi.org/10.1016/j.ymben.2018.09.003.
