function graph_sequential_implementation(obj)
% Wrapper for :func:`graph_sequential_implementation_s`

ResAnalysis.graph_sequential_implementation_s(obj.solutions, obj.solution_ids, obj.prodnet)
