function [res_table, results] = identify_deletion_role(obj,, varargin)
% Wrapper for :func:`idenify_deletion_role`
% base_deletion_set, compare_deletion_set