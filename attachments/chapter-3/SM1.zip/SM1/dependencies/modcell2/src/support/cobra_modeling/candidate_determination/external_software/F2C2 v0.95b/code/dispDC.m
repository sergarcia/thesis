function dispFC(fctable, i)
% Display all reactions that are fully coupled to the one in argument
    find(fctable(i, :)==3)
end

