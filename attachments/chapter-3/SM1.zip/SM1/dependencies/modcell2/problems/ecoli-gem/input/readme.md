# Paramters
minimum growth rate is set to 20% of the parent maximum:
0.1575*0.2 = 0.0315

