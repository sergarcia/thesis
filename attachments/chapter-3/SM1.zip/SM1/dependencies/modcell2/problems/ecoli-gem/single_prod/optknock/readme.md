Single product strain designs calculated with OptKnock for 1,2,3, and 4 deletions.
