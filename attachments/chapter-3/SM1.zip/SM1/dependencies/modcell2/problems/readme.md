Each problem directory contains input files, output, and analysis.

