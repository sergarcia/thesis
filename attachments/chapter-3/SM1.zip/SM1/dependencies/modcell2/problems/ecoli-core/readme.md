# E. coli core

The widely used E. coli core model used for testing, development, and examples.