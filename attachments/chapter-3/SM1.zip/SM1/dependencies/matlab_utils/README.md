General Matlab convinience functions, mostly used to make beautiful figures.
