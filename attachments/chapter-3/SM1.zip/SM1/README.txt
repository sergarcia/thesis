This files correspond to Supplementary Material 1 for the manuscript:

Comparison of Multi-objective Evolutionary Algorithms to Solve the Modular Cell Biocatalyst Design Problem
Sergio Garcia and Cong Trinh
Submitted for review to the Processes MDPI journal.

For updated versions of the files and issues or contributions please visit our github repository:
https://github.com/trinhlab/compare-moe://github.com/trinhlab/compare-moea

The dependencies to the "compare-moea" software have also been included here under the directory "dependencies".
